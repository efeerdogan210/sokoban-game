public class Ground extends Object{
    public Ground(Location location) {
        super(location);
    }

    @Override
    public String toString() {
        return " ";
    }
}
