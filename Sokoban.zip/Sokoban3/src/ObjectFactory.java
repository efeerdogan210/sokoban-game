public interface ObjectFactory {
    Object createObject(Location location);




}
