public class PowerUpSkateBoard extends Object{

    public PowerUpSkateBoard(Location location) {
        super(location);
    }

    @Override
    public String toString() {
        return "S";
    }
}
