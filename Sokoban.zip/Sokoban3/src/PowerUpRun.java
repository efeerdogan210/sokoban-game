public class PowerUpRun extends Object{

    public PowerUpRun(Location location) {
        super(location);
    }

    @Override
    public String toString() {
        return "R";
    }
}
