public class Wall extends Object{

    public Wall (Location location){
     super(location);
    }

    @Override
    public String toString() {
        return "#";
    }
}
