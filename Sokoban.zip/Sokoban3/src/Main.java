public class Main {
    public static void main(String[] args) {


            Game sokoban = new GameScreen();


            sokoban.load();

            sokoban.start();


    }
}