public class Target extends Object{
    public Target(Location location) {
        super(location);
    }

    @Override
    public String toString() {
        return ".";
    }
}
